// In the web build, API calls are same-origin (relative). In the Android app the
// page is served from the device, so set VITE_API_BASE (e.g. https://your-server.com)
// at build time to reach the multiplayer server. Without it, multiplayer is unavailable
// but every offline mode still works.
const BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.replace(/\/$/, '') ?? '';
export const apiUrl = (path: string) => `${BASE}${path}`;
