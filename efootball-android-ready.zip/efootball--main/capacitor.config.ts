import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.efootball.cards',
  appName: 'eFootball Cards',
  webDir: 'dist',
  backgroundColor: '#000000',
  android: { allowMixedContent: true },
};

export default config;
